-- Validate full E2E workflow
SELECT * FROM orders WHERE order_id = :ORDER_ID;
SELECT * FROM slots WHERE order_id = :ORDER_ID;
