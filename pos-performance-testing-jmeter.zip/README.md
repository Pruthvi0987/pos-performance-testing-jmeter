# POS End-to-End Performance Testing (JMeter)

This project simulates an end‑to‑end workflow performance test:

1. **Login**
2. **Create Order**
3. **Reserve Delivery Slot**
4. **Check Order Status**

## Tech Stack
- Apache JMeter
- CSV Data Config
- Postman-compatible payloads
- Assertions + Listeners

## Run the test:
```
jmeter -n -t JMeter_E2E_LoadTest.jmx -l results.jtl
```
